# Техническое задание: Интерактивные геометрические фигуры

## Обзор проекта

Система для отображения интерактивных геометрических фигур с подсветкой элементов для обучения. Используется в образовательном проекте по геометрии.

**Стек:** Alpine.js + Tailwind CSS + SVG

---

## Архитектура

### Структура файлов

```
/components/geometry/
├── utils/
│   ├── angle-arc.js      # Функция для дуг углов
│   └── label-position.js # Функции позиционирования подписей
├── figures/
│   ├── Triangle.html     # Компонент треугольника
│   ├── Circle.html       # Компонент окружности
│   ├── InscribedAngle.html
│   ├── VerticalAngles.html
│   ├── IsoscelesTriangle.html
│   └── ParallelLines.html
└── geometry.css          # Общие стили
```

---

## Критические правила

### 1. Функция дуги угла (ОБЯЗАТЕЛЬНО использовать эту реализацию)

```javascript
/**
 * Рисует дугу угла в вершине vertex между лучами к point1 и point2
 * ВСЕГДА рисует короткую дугу (< 180°)
 * 
 * @param {Object} vertex - вершина угла {x, y}
 * @param {Object} point1 - первая точка на стороне угла {x, y}
 * @param {Object} point2 - вторая точка на стороне угла {x, y}
 * @param {number} radius - радиус дуги в пикселях
 * @returns {string} SVG path строка
 */
function makeAngleArc(vertex, point1, point2, radius) {
  // Углы направлений от вершины к точкам
  const angle1 = Math.atan2(point1.y - vertex.y, point1.x - vertex.x);
  const angle2 = Math.atan2(point2.y - vertex.y, point2.x - vertex.x);
  
  // Точки начала и конца дуги
  const x1 = vertex.x + radius * Math.cos(angle1);
  const y1 = vertex.y + radius * Math.sin(angle1);
  const x2 = vertex.x + radius * Math.cos(angle2);
  const y2 = vertex.y + radius * Math.sin(angle2);
  
  // Нормализуем разницу углов в [-π, π]
  let angleDiff = angle2 - angle1;
  while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI;
  while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;
  
  // sweep-flag: 1 если по часовой, 0 если против
  const sweep = angleDiff > 0 ? 1 : 0;
  
  // large-arc-flag всегда 0 (короткая дуга)
  return `M ${x1} ${y1} A ${radius} ${radius} 0 0 ${sweep} ${x2} ${y2}`;
}
```

**ВАЖНО:** Не модифицировать эту функцию! Она корректно обрабатывает все случаи.

---

### 2. Позиционирование подписей

**Правило:** Подписи точек ВСЕГДА размещаются СНАРУЖИ от фигуры, по направлению от центра фигуры к точке.

```javascript
/**
 * Вычисляет позицию подписи для точки
 * Подпись размещается снаружи от фигуры
 * 
 * @param {Object} point - точка {x, y}
 * @param {Object} center - центр фигуры {x, y}
 * @param {number} distance - расстояние от точки (default: 20)
 */
function labelPos(point, center, distance = 20) {
  const dx = point.x - center.x;
  const dy = point.y - center.y;
  const len = Math.sqrt(dx * dx + dy * dy);
  
  if (len === 0) return { x: point.x, y: point.y - distance };
  
  return {
    x: point.x + (dx / len) * distance,
    y: point.y + (dy / len) * distance
  };
}
```

**Для треугольников:** центр = центроид (среднее арифметическое координат вершин)
```javascript
const center = {
  x: (A.x + B.x + C.x) / 3,
  y: (A.y + B.y + C.y) / 3
};
```

**Для окружностей:** центр = центр окружности

**SVG атрибуты для текста:**
```html
<text 
  :x="labelPos(point, center).x" 
  :y="labelPos(point, center).y"
  text-anchor="middle" 
  dominant-baseline="middle"
  class="geo-label"
>A</text>
```

---

### 3. Правила отображения элементов

**Используй `x-show` вместо `template x-if` для элементов внутри SVG:**

```html
<!-- ПРАВИЛЬНО -->
<g x-show="isHighlighted('angles')">
  <path :d="makeAngleArc(A, B, C, 30)" ... />
</g>

<!-- НЕПРАВИЛЬНО (может не работать в SVG) -->
<template x-if="isHighlighted('angles')">
  <path ... />
</template>
```

---

### 4. Цветовая схема

| Элемент | Цвет по умолчанию | Цвет при подсветке |
|---------|-------------------|-------------------|
| Основные линии | `#dc2626` (красный) | `#f59e0b` (жёлтый) |
| Вспомогательные линии | `#3b82f6` (синий) | — |
| Медианы, биссектрисы | `#10b981` (зелёный) | — |
| Касательные | `#a855f7` (фиолетовый) | — |
| Подписи | `#60a5fa` (голубой) | — |
| Точки | `#dc2626` или цвет элемента | — |

---

### 5. Толщина линий

| Тип линии | Обычная | При подсветке |
|-----------|---------|---------------|
| Основные (стороны, окружности) | 3-3.5px | 5px |
| Вспомогательные (высоты, медианы) | 2.5px | 4px |
| Дуги углов | 2.5-3px | — |
| Пунктирные | `stroke-dasharray="8,5"` | `none` |

---

### 6. Размеры дуг углов

| Тип угла | Радиус дуги |
|----------|-------------|
| Острый угол (< 60°) | 25-30px |
| Обычный угол | 30-35px |
| Тупой угол (> 120°) | 20-25px |
| Прямой угол | Квадратик 12x12px |

---

## Структура компонента Alpine.js

```html
<div x-data="geometryComponent()" class="bg-slate-800 rounded-xl p-6 border border-slate-700">
  <h3 class="text-xl font-semibold text-white mb-4">Название</h3>
  
  <svg viewBox="0 0 300 250" class="w-full h-56 mb-4">
    <!-- Основная фигура -->
    <!-- Вспомогательные элементы (x-show для условного отображения) -->
    <!-- Точки -->
    <!-- Подписи -->
  </svg>

  <!-- Кнопки подсказок -->
  <div class="flex flex-wrap gap-2 mb-3">
    <button 
      @mouseenter="hint = 'element'" 
      @mouseleave="hint = null"
      :class="hint === 'element' ? 'bg-amber-500 text-white' : 'bg-slate-700 text-slate-200'"
      class="px-3 py-1.5 rounded-full text-sm font-medium transition-all"
    >Подсказка</button>
  </div>

  <!-- Описание -->
  <div x-show="hint" x-cloak class="bg-amber-500/20 border-l-4 border-amber-500 p-3 rounded">
    <p class="text-slate-200" x-text="getDescription(hint)"></p>
  </div>
</div>

<script>
function geometryComponent() {
  // Координаты точек
  const A = { x: 50, y: 200 };
  const B = { x: 250, y: 200 };
  const C = { x: 150, y: 50 };
  
  // Центр для позиционирования подписей
  const center = {
    x: (A.x + B.x + C.x) / 3,
    y: (A.y + B.y + C.y) / 3
  };

  return {
    hint: null,
    A, B, C, center,
    
    isHighlighted(name) {
      return this.hint === name;
    },
    
    labelPos(point, center, distance = 20) {
      return window.labelPos(point, center, distance);
    },
    
    makeAngleArc(vertex, p1, p2, radius) {
      return window.makeAngleArc(vertex, p1, p2, radius);
    },
    
    getDescription(hint) {
      const descriptions = {
        'sides': 'Описание сторон',
        'angles': 'Описание углов',
        // ...
      };
      return descriptions[hint] || '';
    }
  };
}
</script>
```

---

## CSS стили

```css
[x-cloak] { display: none !important; }

.geo-line {
  transition: stroke 0.2s ease, stroke-width 0.2s ease;
}

.geo-point {
  transition: r 0.2s ease, fill 0.2s ease;
}

.geo-label {
  font-family: 'Times New Roman', serif;
  font-style: italic;
  font-weight: 500;
  user-select: none;
  pointer-events: none; /* Чтобы не мешали hover на элементах */
}
```

---

## Чеклист перед релизом

- [ ] Все дуги углов рисуются корректно (внутри угла, не снаружи)
- [ ] Подписи не накладываются на линии фигуры
- [ ] При наведении на кнопку элемент подсвечивается
- [ ] Вспомогательные элементы скрыты по умолчанию
- [ ] Цвета соответствуют схеме
- [ ] Линии имеют правильную толщину
- [ ] Текст читаем на тёмном фоне

---

## Примеры использования

### Создание нового компонента "Прямоугольный треугольник"

```javascript
function rightTriangleDemo() {
  // Координаты с прямым углом в C
  const A = { x: 50, y: 50 };
  const B = { x: 250, y: 200 };
  const C = { x: 50, y: 200 }; // Прямой угол здесь
  
  const center = {
    x: (A.x + B.x + C.x) / 3,
    y: (A.y + B.y + C.y) / 3
  };

  return {
    hint: null,
    A, B, C, center,
    
    // Гипотенуза
    get hypotenuse() {
      return { start: this.A, end: this.B };
    },
    
    // Катеты
    get legs() {
      return [
        { start: this.A, end: this.C },
        { start: this.C, end: this.B }
      ];
    },
    
    isHighlighted(name) { return this.hint === name; },
    labelPos(p, c) { return window.labelPos(p, c); },
    makeAngleArc(v, p1, p2, r) { return window.makeAngleArc(v, p1, p2, r); },
    
    // Прямой угол рисуется квадратиком
    rightAnglePath(vertex, p1, p2, size = 12) {
      const angle1 = Math.atan2(p1.y - vertex.y, p1.x - vertex.x);
      const angle2 = Math.atan2(p2.y - vertex.y, p2.x - vertex.x);
      
      const corner1 = {
        x: vertex.x + size * Math.cos(angle1),
        y: vertex.y + size * Math.sin(angle1)
      };
      const corner2 = {
        x: vertex.x + size * Math.cos(angle2),
        y: vertex.y + size * Math.sin(angle2)
      };
      const diagonal = {
        x: corner1.x + size * Math.cos(angle2),
        y: corner1.y + size * Math.sin(angle2)
      };
      
      return `M ${corner1.x} ${corner1.y} L ${diagonal.x} ${diagonal.y} L ${corner2.x} ${corner2.y}`;
    }
  };
}
```

---

## Возможные фигуры для реализации

1. **Базовые:**
   - [x] Треугольник (стороны, высота, медиана, углы)
   - [x] Окружность (радиус, диаметр, хорда, касательная)
   - [x] Вписанный угол
   - [x] Смежные и вертикальные углы
   - [x] Равнобедренный треугольник
   - [x] Параллельные прямые и секущая

2. **Расширенные:**
   - [ ] Прямоугольный треугольник (теорема Пифагора)
   - [ ] Параллелограмм
   - [ ] Трапеция
   - [ ] Вписанная окружность
   - [ ] Описанная окружность
   - [ ] Биссектриса угла
   - [ ] Серединный перпендикуляр
   - [ ] Средняя линия треугольника

---

## Контакты

При возникновении вопросов — обращайтесь к референсному файлу `geometry-alpine-v3.html`
