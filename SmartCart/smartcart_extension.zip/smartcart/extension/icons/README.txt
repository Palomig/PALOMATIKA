Placeholder for icons - download from https://favicon.io/emoji-favicons/ (search for 🛒 shopping cart)
